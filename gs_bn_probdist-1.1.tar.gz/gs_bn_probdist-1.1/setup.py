from setuptools import setup

setup(name='gs_bn_probdist',
      version='1.1',
      description='Gaussian distributions',
      packages=['gs_bn_probdist'],
      author='Himanshu Singh Sikarwar',
      author_email='himanshusingh3639@gmail.com',
      zip_safe=False)
